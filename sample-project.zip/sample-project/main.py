print("Hello, GitHub!")
